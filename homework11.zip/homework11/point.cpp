#include <iostream>
#include <cstdlib>
#include <string>
#include "point.h"

using namespace std;

//point:: tells the compiler that the function is a part of the Point class
//setPoint sets the x and y points equal to the inputs respectively
void Point::setPoint(double num1, double num2)
{
    xpoint = num1;
    ypoint = num2;
}
//setFlag sets the flagpoint to true if the first input is less than the second and false otherwise
void Point::setFlag(double num1, double num2)
{
    bool temp = false;
    if (num1 > num2)
    {
        temp = true;
    }
    flagpoint = temp;
}
//displayInfo just shows the info that was set by the previous functions
void Point::displayInfo()
{
    cout << "x: " << xpoint << endl;
    cout << "y: " << ypoint << endl;
    cout << "flag: " << flagpoint << endl;
}