#include <iostream>
#include <string>
#include <cstdlib>
#include "point.h"

using namespace std;

int main()
{
    //random number seed and creating an array object with 5 elements of class Point
    srand(1);
    Point location[5];
    
    //For loop runs 5 times for each object of the class Point
    for (int i = 0; i < 5; i++)
    {
    //creating random numbers from 0 to 1
    double randNum1 = ((double)rand() / RAND_MAX);
    double randNum2 = ((double)rand() / RAND_MAX);
    
    //calling the mutator functions within the class
    location[i].setPoint(randNum1, randNum2);
    
    location[i].setFlag(randNum1, randNum2);
    
    location[i].displayInfo();
    }
    
    return 0;
}