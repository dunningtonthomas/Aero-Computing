#include <iostream> 
class Point {
  public:
    void setPoint(double, double );
    void setFlag(double, double );
    void displayInfo();
  private:
    double xpoint;
    double ypoint;
    bool flagpoint;
};